<?php

    require 'Entity/Notification.php';
    require 'Form/NotificationForm.php';
    require 'Datatable/NotificationTable.php';
    require 'Controller/NotificationController.php';
    require 'Controller/NotificationFrontController.php';

    require 'Entity/Notificationbroadcasted.php';
    require 'Form/NotificationbroadcastedForm.php';
    require 'Datatable/NotificationbroadcastedTable.php';
    require 'Controller/NotificationbroadcastedController.php';
    require 'Controller/NotificationbroadcastedFrontController.php';


    require 'Entity/Notificationtype.php';
    require 'Form/NotificationtypeForm.php';
    require 'Datatable/NotificationtypeTable.php';
    require 'Controller/NotificationtypeController.php';

